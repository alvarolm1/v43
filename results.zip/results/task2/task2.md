# SECUENCIAL
En la siguiente imagen se muestra el resultado de ejcutar la tarea 1 de forma secuencial

![](https://github.com/ASIGNATURA-ARCO-UCLM/lab2-alvaro-lopez-megia/blob/main/results/task2/Captura%20desde%202023-10-25%2022-59-48.png)

----

# PARALELIZABLE
En la siguiente imagen se muestra el resultado de ejceutar la tarea 1 de forma paralela

![](https://github.com/ASIGNATURA-ARCO-UCLM/lab2-alvaro-lopez-megia/blob/main/results/task2/Captura%20desde%202023-10-25%2023-07-26.png)

----

Cómo podemos observar el tiempo de la versión secuencial es 0.000022 segundos mientras que el de la versión paralela es 0.000877 segundos.
Al igual que en la tarea 1, la versión paralelizable debería tener un tiempo de ejecución menor que el de la versión secuencial pero en este caso la complejidad del programa es baja por lo que la paralelización incrementa el tiempo de ejecución.
Como conlusión, en este programa no es rentable obtener su versión paralela.
