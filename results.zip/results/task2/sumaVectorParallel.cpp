/* Programa secuencial que calcula la suma de los elementos de un vector v[i] 
 * y la almacena en la variable sum */ 

#include <stdio.h> 
#include <stdlib.h> 
#include <time.h> 
#include <omp.h>
#define N 50 // Probar distintos tamaños de vector 
double start;
double end;
int i, sum = 0; 
int v[N];  

int main() 
{ 
    start=omp_get_wtime();
    omp_set_num_threads(50);
    #pragma omp parallel
    {
        //Dar valores aleatorios al vector entre 0 y 9
        int valor=rand()%100;
        v[i]=valor;

        //Calcular sumatorio
        sum += v[i];
        i++;
    }  

    // Como comprobación, se visualizan los valores del vector y la suma 
    printf("\nVector de números: \n "); 
    for (i = 0; i < N; i++) printf("%d \t",v[i]);
    end=omp_get_wtime();
	printf("\n La suma es: %d \n\n", sum); 
    printf("El tiempo de ejecución es %f \n",end-start);
} 