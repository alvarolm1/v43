# SECUENCIAL
En la siguiente imagen se muestra el resultado de ejcutar la tarea 1 de forma secuencial

![](https://github.com/ASIGNATURA-ARCO-UCLM/lab2-alvaro-lopez-megia/blob/main/results/task3/Captura%20desde%202023-10-25%2023-13-23.png)

----

# PARALELIZABLE
En la siguiente imagen se muestra el resultado de ejceutar la tarea 1 de forma paralela

![](https://github.com/ASIGNATURA-ARCO-UCLM/lab2-alvaro-lopez-megia/blob/main/results/task3/Captura%20desde%202023-10-25%2023-19-05.png)

----

Cómo podemos observar el tiempo de la versión secuencial es 0.000025 segundos mientras que el de la versión paralela es 0.00037 segundos.
A priori, la versión paralelizable debería tener un tiempo de ejecución menor que el de la versión secuencial pero en este caso la complejidad del programa no es muy grande por lo que la paralelización incrementa el tiempo de ejecución.
Como conlusión, este programa obtiene un tiempo de ejecución menor en su versión secuencial
